import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:scorebooster/users/test_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized(); // Ensures plugin binding
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp, // Lock to Portrait mode
  ]).then((_) {
    runApp(MyApp());
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    DeviceOrientation.portraitUp;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Score Booster',
      theme: ThemeData(
        colorScheme: ColorScheme.light(
          primary: const Color.fromARGB(255, 1, 33, 105),
          secondary: const Color(0xFF03DAC6),
          surface: const Color(0xFFFFFFFF),
          error: const Color(0xFFB00020),
          onPrimary: const Color.fromARGB(255, 1, 33, 105),
          onSecondary: const Color(0xFF000000),
          onSurface: const Color(0xFF000000),
          onError: const Color(0xFFFFFFFF),
        ),
        useMaterial3: true,
      ),
      home: QuizPage(),
    );
  }
}
